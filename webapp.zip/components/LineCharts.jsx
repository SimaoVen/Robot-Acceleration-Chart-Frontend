import React from 'react';

let refresh_interval = 5;

async function fetchData() {
  const response = await fetch('https://iscf-lab1-default-rtdb.europe-west1.firebasedatabase.app/Accel.json');
  if(!response.ok) {
    throw new Error('Failed retrieving data from firebase');
  }
  const data = await response.json();
  const keys = Object.keys(data);
  const newData = [keys.length];
  for(let i = 0; i < keys.length; i++) {
    newData[i] = {
      timestamp: new Date(data[keys[i]].timestamp * 1000).toUTCString(),
      x: data[keys[i]].x,
      y: data[keys[i]].y,
      z: data[keys[i]].z
    }
  }
  return newData;
}

function updateChart() {
  fetchData().then(data => {
    const time = data.map(item => item.timestamp);
    const x = data.map(item => item.x);
    const y = data.map(item => item.y);
    const z = data.map(item => item.z);
    console.log(time,x,y,z);
  });
}

setInterval(updateChart, refresh_interval * 1000);

const LineCharts = () => {
  return (
    <>
      <div className='w-full relative lg:h-[80vh] h-[40vh] m-auto p-4 border rounded-lg bg-white'>
        <div><canvas id='X_Accel'></canvas></div>
        <div><canvas id='Y_Accel'></canvas></div>
        <div><canvas id='Z_Accel'></canvas></div>
      </div>
    </>
  );
}

export default LineCharts
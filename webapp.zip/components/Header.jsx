import React from 'react'

const Header = () => {
  return (
    <div className='flex justify-between px-4 pt-4'>
      <h2>ISCF Lab1</h2>
      <h2>2022/2023 NOVA SST</h2>
    </div>
  )
}

export default Header
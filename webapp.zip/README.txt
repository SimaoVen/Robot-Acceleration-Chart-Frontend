A usar os pacotes: chart.js react-chartjs-2 react-icons tailwindcss

Necessário instalar para não dar erro.